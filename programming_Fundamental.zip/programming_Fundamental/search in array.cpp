
#include<fstream>
#include<iostream>
using namespace std;
int main()
{
	int array[8],find;
	ofstream thefile;
	thefile.open("The File");
	for(int i=0;i<8;i++)
	{
		cout<<"Enter an element:";
		cin>>array[i];
		cout<<"\n";
		thefile<<array[i]<<"\n";
	}
	cout<<"Enter searching element:";
	cin>>find;
	thefile<<"Enter searching element:"<<find<<endl;
	for(int i=0;i<8;i++)
	{
		if(find==array[i])
		{
			cout<<"searching element is:"<<i+1;
			thefile<<"searching element is:"<<i+1;
		}
	}
	thefile.close();
	return 0;	
}
