#include<iostream>
using namespace std;
int main()
{
       int row,i,j,k;
       cout<<"Enter the value ";
       cin>>row;
       for(i=0;i<row;i++)
    {
      for(j=row;j>i;j--)
        cout<<" ";
      for(k=0;k<=row+j-1;k++)
        cout<<"* ";
      cout<<endl;
    }
    for(i=1;i<row;i++)
    {
      for(j=0;j<=i;j++)
        cout<<" ";
      for(k=0;k<=2*row-j-1;k++)
        cout<<"* ";
      cout<<endl;
    }
    return 0;
}

