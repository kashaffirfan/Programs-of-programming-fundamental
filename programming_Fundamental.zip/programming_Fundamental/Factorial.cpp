#include<iostream>
using namespace std;
int main()
{
	int num,a=1;
	cout<<"Enter number: ";
	cin>>num;
	if(num>=0)
	{
	
	while(num!=0)
	{
	a=a*num;
	num--;	
	}
	cout<<"Factorial is: "<<a;
    }
    else
    cout<<"Invalid Input";
return 0;
}

