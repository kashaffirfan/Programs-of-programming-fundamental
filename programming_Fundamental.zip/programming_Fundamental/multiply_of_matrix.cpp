
#include<iostream>
#include<cstring>
using namespace std;

int main()
{
	int matrix1[100][100], matrix2[100][100], mul[100][100], row1, row2, col1, col2,sum=0;
	cout<<"Enter no of rows of matrix1: ";
	cin>>row1;
	cout<<"Enter no of coloumns of matrix1: ";
	cin>>col1;
	for(int i=0;i<row1;i++)
	{
		for(int j=0;j<col1;j++)
		{
			cin>>matrix1[i][j];
				
		}
		
	}
	cout<<"Enter no of rows of matrix2: ";
	cin>>row2;
	cout<<"Enter no of coloumns of matrix2: ";
	cin>>col2;
	for(int i=0;i<row2;i++)
	{
		for(int j=0;j<col2;j++)
		{
			cin>>matrix2[i][j];
				
		}	
	}
	if(col1!=row2)
	{
		cout<<"Multiplication cannot be done"<<endl;
	}
	else
	{
		for(int i=0;i<row2;i++)
		{
			for(int j=0;j<col2;j++)
			{
				sum=0;
				for(int k=0;k<row2;k++)
				{
					sum=sum+(matrix1[i][k]*matrix2[k][j]);
					mul[i][j]=sum;
				}
			}	
		}
	}
	for(int i=0;i<row2;i++)
	{
		for(int j=0;j<col2;j++)
		{
			cout<<mul[i][j]<<" ";		
		}
		cout<<endl;
	}	
	return 0;
}

