#include<iostream>
using namespace std;
int zero = 0;
int nonzero = 0;
int fun(int number)
{
	int num1;
	while (number > 0)
	{
		num1 = number % 10;
		if (num1 == 0)
		{
			zero++;
		}
		if (num1 != 0)
		{ 
			nonzero++;
		}
		number = number / 10;
	}
	return 0;
}
int main()
{
	int num;
	cout << "Enter a number : ";
	cin >> num;
	fun(num);
	cout <<"Zeroes: " << zero << endl;
	cout << "Non-Zeroes: " << nonzero << endl;
	return 0;
}


