#include <iostream>
#include <fstream>
using namespace std;

int main() {
 

  ifstream my_read;
  string ch;
  int count=0;
  my_read.open("OUT.txt");
  while(!my_read.eof())
  {
  	getline(my_read,ch);
  	cout<<ch;
  }
  for(int i=0;i<ch.length();i++)
  {
  	
	  	count++;
	  
  }
  cout<<endl;
  cout<<"Total Characters: "<<count;
  cout<<endl;
}


