#include<iostream>
using namespace std;
int main(){
	int i,height,j;
	char ch;
	cout<<" Enter height: ";
	cin>>height;
	for( i=height;i>=1;i--)
	{
	 	ch='a';
	{
		for( j=1;j<=i;j++)
		{
	 		cout<<ch++;
    	}
    }
cout<<endl;
}
system("pause");
return 0;
}

