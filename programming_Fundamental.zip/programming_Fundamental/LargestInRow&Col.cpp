#include<iostream>
using namespace std;
int main()
{
	int larColumn, larRow;
	int array[3][3];
	cout << "Enter an array of 3x3 : " << endl;
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cin >> array[i][j];
		}
		cout << endl;
	}
	int column;
	int row;
	cout << "\nEnter Number of column : ";
	cin >> column;
	cout << "\nEnter number of row : ";
	cin >> row;

				for (int k = 0; k < 3; k++)
				{
					larColumn = array[k][column-1];
					for (int l = 1; l < 3; l++) {
						if (array[l][column - 1] > larColumn)
						{
							larColumn = array[l][column - 1];
						}
					}
				}
	for (int i = 0; i < 3; i++)
	{
		larRow = array[row - 1][0];
		for (int j = 1; j < 3; j++)
		{
			if (array[row - 1][j] >larRow)
			{
				larRow = array[row - 1][j];
			}
		}
	}
	cout << "\nLargest element in your given column is : " << larColumn << endl;
	cout << "\nLargest element in your given row is : " << larRow << endl;
	system("pause");
}

