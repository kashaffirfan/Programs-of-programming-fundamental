#include<iostream>
#include<iomanip>
using namespace std;
int const small=9,medium=12,large=15;
float const scost=1.75,mcost=1.90,lcost=2.00;
char choice;
int count=0,s=0,m=0,l=0;
void coffeeProgram()
{
	
	cout<<setw(40)<<left<<" ";
	cout<<"Welcome of Jason's coffee shop"<<endl;
	cout<<setw(40)<<right<<" "<<endl;
	cout<<"Our Coffee menu is given below:"<<endl<<"Small cup"<<setw(10)<<"Rs."<<scost<<endl<<"Medium cup"<<setw(10)<<"Rs."<<mcost<<endl<<"Large cup"<<setw(10)<<"Rs."<<lcost;
	
}
void selling()
{
	cout<<endl<<"Select your size:"<<endl<<"Enter S for small,M for medium,L for large & E to end your order:";
	do
	{
	cin>>choice;
	count++;
	if(choice=='S')
	s++;
	if(choice=='M')
	m++;
	if(choice=='L')
	l++;
	}
	while(choice!='E');
}
void cups()
{
	cout<<"Total number of sold small cups:"<<s<<endl;
	cout<<"Total number of sold medium cups:"<<m<<endl;
	cout<<"Total number of sold large cups:"<<l<<endl;
}
void amount()
{
	cout<<"Total amount of coffee sold:"<<s*small+m*medium+l*large<<"oz"<<endl;
}
float money()
{
	float money;
	money=s*scost+m*mcost+l*lcost;
	cout<<"Total amount of money:Rs."<<money;
	return money;	
}
int main()
{
	coffeeProgram();
	selling();
	cups();
	amount();
	money();
	return 0;
}
