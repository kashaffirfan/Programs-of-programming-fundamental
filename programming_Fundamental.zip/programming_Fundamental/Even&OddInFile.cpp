#include<fstream>
#include<iostream>
using namespace std;
int main()
{
	int array[8],odd[8],even[8];
	ofstream file;
	file.open("Numbers.txt");
	file<<"Numbers{";
	for(int i=0;i<8;i++)
	{
		cin>>array[i];
		file<<array[i]<<" ";
	}
	file<<"}"<<endl<<"Odd Numbers:{";
	int j=0;
	for(int i=0;i<8;i++)
	{
		if(array[i]%2!=0)
		{
			odd[j]=array[i];
		 	file<<odd[j]<<" ";
			j++;		
		}	
	}
	file<<"}"<<endl<<"Even Numbers:{";
	for(int i=0;i<8;i++)
	{
		if(array[i]%2==0)
		{
			even[j]=array[i];
		 	file<<even[j]<<" ";
			j++;		
		}	
	}
	file<<"}";
	return 0;
}
