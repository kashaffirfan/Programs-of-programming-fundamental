#include <iostream>
using namespace std;
int main()
{
  int i,j;
  int n;
  cout<<"Enter height:";
  cin>>n;
   for(i=1;i<=n;i++)
    {
 
		for(j=1;j<=n-i;j++)
        {
            cout<<" ";
        }
        for(j=1;j<=i;j++)
        {
            cout<<static_cast<char>(j+96);
        }
        for(j=i-1;j>=1;j--)
        {
            cout<<static_cast<char>(j+96);
        }
        cout<<endl;
    }
  return 0;
}
