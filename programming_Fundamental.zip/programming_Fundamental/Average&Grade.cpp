#include <iostream>
#include <cstring>
using namespace std;

void name(int n)
{
	string str[10];
	for (int i = 0; i < n; i++)
	{
		cin >> str[i];
	}
	return;
}
double avegrade(int ro, int c)
{
	int sum, count, avg, num = 0, counter = 1;
	int str1[10][10];
	cout << "Total student for marks = ";
	cin >> ro;
	cout << "Enter number of Marks = ";
	cin >> c;
	for (int j = 0; j < ro; j++)
	{
		sum = 0;
		avg = 0;
		count = 0;
		for (int k = 0; k < c; k++)
		{
			cin >> str1[j][k];
			sum = sum + str1[j][k];
			num = num + str1[j][k];
			count++;
			counter++;
		}
		avg = sum / count;
		cout << "student number " << 1 + j << " average = " << avg << endl;
		if (avg >= 85)
		{
			cout << "A Grade";
		}
		else if (avg >= 75)
		{
			cout << "B Grade";
		}
		else if (avg >= 60)
		{
			cout << "C Grade";
		}
		else if (avg >= 50)
		{
			cout << "D Grade";
		else
		{
			cout << "F Grade";
		}
		cout << endl;
	}
	cout << "Total Class averge = " << num / counter << endl;
	return 0;
}
int main()
{
	int nos, ro=0, c=0;
	cout << "Enter Number of students = ";
	cin >> nos;
	name(nos);
	cout << avegrade(ro, c);
	system("pause");
}


