#include<iostream>
#include<cstring>
using namespace std;

int main()
{
	int lg;
	char line[70];
	cout <<"Enter a string less than 70"<<endl;
	cin.getline(line,70);
	cout<<endl<<"Length of string is: "<<strlen(line);
	return 0;
}

