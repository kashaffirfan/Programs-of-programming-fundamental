#include<iostream>
using namespace std;
int* pointer[10];
void function(int arr[10])
{
	cout << "Enter the numbers in the array : ";
	for (int i = 0; i < 10; i++)
	{
		cin >> arr[i];
	}
}
void function2(int arr[10],int number)
{

	for (int i = 10 - number,j=0; i < 10 ; i++,j++)
	{
		pointer[j] = &(arr[i]);
	}
	int j = 0;
	for (int i = number ; i < 10; i++,j++)
	{
		pointer[i] = &(arr[j]);
	}
	cout << "Shifted array is : ";
	for (int i = 0; i < 10; i++)
	{
		cout << *pointer[i] << "  ";
	}
}
int main()
{
	int arr1[10];
	int num;
	cout << "Enter a number : ";
	cin >> num;
	function(arr1);
	function2(arr1, num);
	system("pause");
	return 0;
}

