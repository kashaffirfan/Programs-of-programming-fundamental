#include<iostream>
using namespace std;
int main()
{
	int height,width;
	char ch;
	ch = 'a';
	cout << "Enter height:";
	cin >> height;
	cout<<endl;
	cout << "Enter width:";
	cin >>width;
	for (int i = 1; i <=height; i++)
	{
		for (int j = 1; j <=width; j++)
		{
			static_cast<int>(ch);
			if (ch == 97 )
			{
				cout << ch;
				ch = ch + 4;
			}
			else if (ch == 101) 
			{
				cout << ch;
				ch = ch + 4;
			}
			else if (ch == 105)
			{
				cout << ch;
				ch = ch + 6;
			}
			else if (ch == 111)
			{
				cout << ch;
				ch = ch + 6;
			}
			else if (ch == 117)
			{
				cout << ch;
				ch = 97;
			}
		}
		cout << endl; 
	}
	system("pause");
	return 0;
}
