#include <iostream>
#include <conio.h>
using namespace std;
int main()
{
    int i,j,height;
    cout<<"Enter height:";
    cin>>height;
    if(height%2==1)
	{
	for(i=1; i<=height; i++)
	{
    	for(j=height; j>i; j--)
		{
       		cout<<" ";
    	}
    cout<<"*";//print star
    	for(j=1; j<(i-1)*2; j++)
		{
       		cout<<" ";
    	}
    if(i==1)
	{
      	cout<<"\n";
    }
    else
	{
      cout<<"*\n";
    }
	}
	for(i=height-1; i>=1; i--)
	{
    	for(j=height;j>i;j--)
		{
       		cout<<" ";
    	}
    	cout<<"*";
    	for(j=1; j<(i-1)*2; j++)
		{
      		cout<<" ";
    	}
    	if(i==1)
		{
    		cout<<endl;
    	}
    	else
		{
    		cout<<"*\n";
    	}
	}
    }
    else
    cout<<"Its an even number";
    system("pause");
return 0;
}
    
    
    
    
