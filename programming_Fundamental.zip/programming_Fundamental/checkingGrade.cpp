#include <iostream>
using namespace std;
int main()
{
	char grade;
	cout<<"Enter grade: ";
	cin>>grade;
	if(grade=='A')
	{
		cout<<"\nExcellent";
	}
	else if(grade=='B')
	{
		cout<<"\nGood";
    }
    else if(grade=='C')
	{
		cout<<"\nAverage";
	}
	else if(grade=='D')
	{
		cout<<"\nPoor";
	}
	else if(grade=='F')
	{
		cout<<"\nFail";
	}
	else
	{
		cout<<"Invalid input";
	}
}
 
