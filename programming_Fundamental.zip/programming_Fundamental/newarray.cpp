#include<stdio.h> 
void newArryPrevNext(int array[], int n) 
{ 
    if (n <= 1) 
      return; 
    int pre_elem = array[0]; 
    array[0] = array[0] * array[1]; 
    for (int i=1; i<n-1; i++) 
    { 
        int cur_elem = array[i]; 
        array[i] = pre_elem * array[i+1]; 
        pre_elem = cur_elem; 
    } 
    array[n-1] = pre_elem * array[n-1]; 
} 
int main() 
{ 
    int array[] = {1,2, 3, 4, 5, 6}; 
    int n = sizeof(array)/sizeof(array[0]); 
	int i = 0; 	
	printf("The array is:  \n");
	for(i = 0; i < n; i++)
		{
			printf("%d  ", array[i]);
		}
	printf("\n");
	printf("The new array is: \n");	
    newArryPrevNext(array, n); 
    for (int i=0; i<n; i++) 
      printf("%d ", array[i]); 
    return 0; 
    system("pause");
}
