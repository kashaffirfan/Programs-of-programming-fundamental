#include<iostream>
#include<string>
#include<iomanip>
using namespace std;
int main()
{
	float adultt, childt,no_adultt,no_childt,grossAmount,per,amountDonated,netSaleAmount;
	string movie_name;
	cout << "Enter movie name :" << endl;
	getline(cin, movie_name);
	cout << "Enter the price of an adult ticket :" << endl;
	cin >> adultt;
	cout << "Enter the price of a child ticket :" << endl;
	cin >> childt;
	cout << "Enter adults ticket sold :" << endl;
	cin >> no_adultt;
	cout << "Enter child ticket sold :" << endl;
	cin >> no_childt;
	cout << "Enter the percentage of gross amount to be donated :" << endl;
	cin >> per;
	grossAmount = adultt* no_adultt + childt*no_childt;
	amountDonated = grossAmount * per / 100;
	netSaleAmount = grossAmount - amountDonated;
	cout << setw(20) << left << " ";
	cout << "________________________*" << endl;
	cout << setw(20) << left << " ";
	cout << "Movie name :..........";
	cout << setw(15) << right << " ";
	cout<< movie_name << endl;
	cout << setw(20) << left << " ";
	cout << "Number of Tickets Sold :..........";
	cout << setw(12) << right << " "; 
	cout << (no_adultt+no_childt) << endl;
	cout << setw(20) << left << " ";
	cout << "Gross Amount :..........";
	cout << setw(18) << right << " "; 
	cout << grossAmount << "%" << endl;
	cout << setw(20) << left << " ";
	cout << "Percentage of Gross Amount Donated :........";
	cout << setw(2) << right << " "; 
	cout << per << endl;
	cout << setw(20) << left << " ";
	cout << "Amount Donated :..........";
	cout << setw(15) << right << " "; 
	cout << amountDonated << endl;
	cout << setw(20) << left << " ";
	cout << "Net Sale :..........";
	cout << setw(18) << right << " "; 
	cout << netSaleAmount << endl;
	cout << setw(20) << left << " ";
cout << "________________________*" << endl;

	system("pause");
	return 0;
}
