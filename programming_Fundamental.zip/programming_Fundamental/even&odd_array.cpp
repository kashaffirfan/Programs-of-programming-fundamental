#include<iostream>
#include<cstring>
using namespace std;

int main()
{
	int array[2][2], odd=0;
	cout<<"Enter numbers:  ";
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			cin>>array[i][j];
			if(array[i][j]%2!=0)
			{
				odd++;
			}
		}
	}
	cout<<"Even numbers in array are : ";
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			if(array[i][j]%2==0)
			cout<<array[i][j]<<" "<<" ";
		}	
	}
	cout<<endl<<"Number of odds in array are: "<<odd;
	return 0;
}

