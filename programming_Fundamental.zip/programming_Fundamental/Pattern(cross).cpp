#include <iostream>
using namespace std;
int main()
{ 
    int height; 
    cout << "Enter height:";
    cin >> height;
    if(height%2!=0)
    {
    	for (int i = 1; i <= height; i++)
		{
        	for (int j = 1; j <= height; j++) 
        	{
            	if (j == i || j == (height+ 1 - i))
                	cout << "*"; 
            	else
                	cout << " ";
        	}
        	cout << endl;
    	}
	}
	else
	cout<<"Its an even number";
	system("pause");
    return 0;
}
