#include <iostream>
#include <fstream>
using namespace std;
int main()
{
	int coke = 0, dew = 0, mirinda = 0, sprite = 0, exit = 5;
	int option = 0, participated = 0, total = 0;
	fstream survey1;
	fstream survey2;
	cout << "Press 1 if you like coke." << endl;
	cout << "Press 2 if you like dew." << endl;
	cout << "Press 3 if you like mirinda." << endl;
	cout << "Press 4 if you like sprite." << endl;
	cout << "Press 5 to exit." << endl;
	while (option != 5)
	{
		cin >> option;
		if (option > 0 && option < 6)
		{
			switch (option)
			{
			case 1:
			{
				coke++;
				break;
			}
			case 2:
			{
				dew++;
				break;
			}
			case 3:
			{
				mirinda++;
				break;
			}
			case 4:
			{
				sprite++;
				break;
			}
			}
			participated++;
		}
	}
	survey1.open("SurveyResults1.txt", ios::app);
	survey1 << endl;
	survey1 << "People participated: " << participated << endl;
	survey1 << "Coke   : " << "\t" << coke << " " << "\t";
	for (int i = 0; i < coke; i++)
	{
		survey1 << "*";
	}
	survey1 << endl;
	survey1 << "Dew    : " << "\t" << dew << " " << "\t";
	for (int i = 0; i < dew; i++)
	{
		survey1 << "*";
	}
	survey1 << endl;
	survey1 << "Mirinda: " << "\t" << mirinda << " " << "\t";
	for (int i = 0; i < mirinda; i++)
	{
		survey1 << "*";
	}
	survey1 << endl;
	survey1 << "Sprite : " << "\t" << sprite << " " << "\t";
	for (int i = 0; i < sprite; i++)
	{
		survey1 << "*";
	}
	survey1.close();
}
