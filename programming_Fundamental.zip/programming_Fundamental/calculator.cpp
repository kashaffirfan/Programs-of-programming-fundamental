#include<iostream>
using namespace std;
int main()
{
	int mul,div,add,sub,num1,num2;
	char choice;
	cin>>num1;
	cin>>num2;
	cout<<"Enter choice:";
	cin>>choice;
	if(choice=='M')
	{
		cout<<"Your answer is:"<<num1*num2;
	}
	else if(choice=='D')
	{
		div=num1/num2;
		cout<<"Your answer is:"<<div;
	}
	else if(choice=='S')
	{
		sub=num1-num2;
		cout<<"Your answer is:"<<sub;
	}
	else if(choice=='A')
	{
		add=num1+num2;
		cout<<"Your answer is:"<<add;
	}
	else
	cout<<"Invalid choice";
	system("pause");
	return 0;
	
	
	
	
	
	
	
	
	
	
	
}
