#include<iostream>
using namespace std;
int main ()
{
	int coke=0,dew=0,mirinda=0,sprite=0,people;
	cout<<"Enter number of people:";
	cin>>people;
	int choice;
	for(int i=1;i<=people;i++)
	{
		cout<<"Enter 1 for coke,2 for dew,3 for mirinda,4 for sprite & 5 to exit:";
		cin>>choice;
		if(choice==1)
		coke++;
		else if(choice==2)
		dew++;
		else if(choice==3)
		mirinda++;
		else if(choice==4)
		sprite++;
		else if(choice==5)
		break;
	}
	cout<<"\nNumber of People in survey:"<<people<<endl<<"Coca cola:	"<<coke<<"	";
	for(int i=1;i<=coke;i++)
	{
		cout<<"*";
	}
	cout<<endl<<"Dew:		"<<dew<<"	";
	for(int i=1;i<=dew;i++)
	{
		cout<<"*";
	}
	cout<<endl<<"Mirinda:	"<<mirinda<<"	";
	for(int i=1;i<=mirinda;i++)
	{	
		cout<<"*";
	}
	cout<<endl<<"Sprite:		"<<sprite<<"	";
	for(int i=1;i<=sprite;i++)
	{
		cout<<"*";
	}
return 0;
}
