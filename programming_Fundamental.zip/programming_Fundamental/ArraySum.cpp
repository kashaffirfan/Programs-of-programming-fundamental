#include<iostream>
using namespace std;
int main()
{
    int sum=0;
    int arr[5];
    for (int i = 0; i < size; i++)
    {
        cin>>arr[i];
        sum = sum + arr[i];
    }
    cout << sum;
    system("pause");
    return 0;
}


