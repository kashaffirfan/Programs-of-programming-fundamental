#include<iostream>
using namespace std;

void matrix(int a[3][3]);

int main() {
	int arr[3][3];
	cout << "Enter matrix value:" << endl;
	for (int row = 0; row < 3; row++)
	{
		for (int col = 0; col < 3; col++)
		{
			cin >> arr[row][col];
		}
	}

	matrix (arr);

	system("pause");
	return 0;
}

void matrix(int a[3][3])
{
	int b[3][3];
	bool flag = false;


	cout << "Before Transpose" << endl;
	for (int row = 0; row < 3; row++)
	{
		for (int col = 0; col < 3; col++)
		{
			cout << a[row][col] << "  ";
		}
		cout << endl;
	}

	for (int row = 0; row < 3; row++)
	{
		for (int col = 0; col < 3; col++)
		{
			b[row][col] = a[col][row];
		}
		cout << endl;
	}

	cout << "After Transpose" << endl;
	for (int row = 0; row < 3; row++)
	{
		for (int col = 0; col < 3; col++)
		{
			cout << b[row][col] << "  ";
		}
		cout << endl;
	}


	for (int row = 0; row < 3; row++)
	{
		for (int col = 0; col < 3; col++)
		{
			if (a[row][col] != b[row][col])
			{
				flag = true;
			}
		}
		cout << endl;
	}

	if (flag == false)
	{
		cout << "Your matrix is Symmetric" << endl;
	}
	else
	{
		cout << "Your matrix is not Symmetric" << endl;
	}
}
