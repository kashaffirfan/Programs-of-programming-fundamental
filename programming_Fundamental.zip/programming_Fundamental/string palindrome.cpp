#include<iostream>
#include<cstring>
using namespace std;

int main()
{
	int len=0;
	bool flag=0;
	char line[50];
	cout << "Enter string less than 50"<<endl;
	cin.getline(line,50);
	len=strlen(line);
	cout<<endl;
	for(int i=0;i<len;i++)
	{
		
		if(line[i]!=line[len-1])
		flag=1;
		len--;
	}
	if(flag==0)
	cout<<"Palindrome";
	else
	cout<<"Not a palindrome";
	return 0;
}

