#include<iostream>
#include<cmath>
#include<fstream>
#include<iomanip>
#include<string>
#include<cstdlib>
using namespace std;
int main()
{
	
	char arr[13][6];
	string result, answer1;
	int count = 0;
	int row, col;
	cout << "Confirm seats for booking." << endl;
	for (int i = 0; i < 13; i++)
	{
		for (int j = 0; j < 6; j++)
		{
			if (rand() % 2 == 0)
			{
				arr[i][j] = '*';
				count++;
			}
			else
			{
				arr[i][j] = 'x';
			}
		}
	}
	char X;
	cout << "       ";
	for (X = 'A'; X <= 'F'; X++)
	{
		cout << X << "   ";
	}
	cout << endl;
	cout << endl;
	for (int i = 0; i < 13; i++)
	{
		if (i < 9)
			cout << "Row " << i + 1 << setw(3);
		else
			cout << "Row " << i + 1 << setw(2);
		for (int j = 0; j < 6; j++)
		{
			cout << arr[i][j] << "   ";
		}
		cout << endl;
	}
	int i = 0, num=0;
	cout << endl;
	cout << " Available seats:" << count;
	cout << endl;
	cout << "Do you want to purchase the tickets? : " << endl;
	getline(cin, result);
	if (result == "No")
		return 0;
	while (result == "Yes")
	{
		while (num != 4)
		{
			cout << "Enter the ticket type:" << endl;
			cout << "1. First Class \n 2. Business Class \n 3. Economy Class \n" << "4. Exit " << endl;
			cout << "Press option to select from the following classes: " << endl;
			cin >> num;


			if (num == 4)
				return 0;
			cout << endl;
			cout << "Enter row and the seat number: " << endl;
			if (num == 1)
			{
				cout << "Select your seat Between Row 1 and Row2: " << endl;
				cin >> row;
				cin >> col;
				while (row > 2)
				{
					cout << "Enter row number again it cannot be greater than 2 " << endl;
					cin >> row >> col;
				}

				break;
			}
			else	if (num == 2)
			{
				cout << "Select your seat Between Row 3 and Row 7: " << endl;
				cin >> row;
				cin >> col;
				while (row > 7 || row < 3)
				{
					cout << "Enter row and seat number again it cannot be greater than 7 and less than 3: " << endl;
					cin >> row >> col;
				}
				break;
			}
			else if (num == 3)
			{
				cout << "Select your seat Between Row 8 and Row13: " << endl;
				cin >> row;
				cin >> col;
				while (row > 13 || row < 8)
				{
					cout << "Enter row and seat number again it cannot be greater than 13 and less than 8: " << endl;
					cin >> row >> col;
				}
				break;
			}
		}
		if (arr[row - 1][col - 1] == '*')
			arr[row - 1][col - 1] = 'x';
		else if (arr[row - 1][col - 1] == 'x')
		{
			cout << "Selected Seat is reverved please enter data again" << endl;
			continue;
		}
		getline(cin, result);
		cout << "You have booked Seat Number: " << col << " in Row: " << row;
		count--;
		cout << endl;
		cout << endl;
		cout << "Do you want to purchase other tickets? :" << endl;
		cin >> result;
		if (result == "No")
			break;
	}
	cout << "       ";
	for (X = 'A'; X <= 'F'; X++)
	{
		cout << X << "   ";
	}
	cout << endl;
	cout << endl;
	for (int i = 0; i < 13; i++)
	{
		if (i < 9)
			cout << "Row " << i + 1 << setw(3);
		else
			cout << "Row " << i + 1 << setw(2);
		for (int j = 0; j < 6; j++)
		{
			cout << arr[i][j] << "   ";
		}
		cout << endl;
	}
	system("pause");
}


