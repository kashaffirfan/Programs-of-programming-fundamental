#include <iostream>
using namespace std;
int main()
{
	char choice;
	int m1[10][10], m2[10][10], result[10];
	int r, c, i, j, sum, product, count = 0;
	cout << "Enter Rows = ";
	cin >> r;
	cout << "Enter Columns = ";
	cin >> c;
	cout << "First Matrix = ";
	for (i = 0; i < r; i++)
	{
		for (j = 0; j < c; j++)
		{
			cin >> m1[i][j];
		}
	}
	cout << "Second Matrix = ";
	for (i = 0; i < r; i++)
	{
		for (j = 0; j < c; j++)
		{
			cin >> m2[i][j];
		}
	}
	cout << "Select A For using program and other for exit" << endl;
	cout << "Enter choice = ";
	cin >> choice;
	do
	{
		char op;
		cout << "Enter Operation = ";
		cin >> op;
		switch (op)
		{
		case '+':
			for (i = 0; i < r; i++)
			{
				for (j = 0; j < c; j++)
				{
					sum = m1[i][j] + m2[i][j];
					cout << sum << "\t";
				}
				cout << endl;
			}
			break;
		case '*':
			for (i = 0; i < r; i++)
			{
				for (j = 0; j < c; j++)
				{
					product = m1[i][j] * m2[i][j];
					cout << product << "\t";
				}
				cout << endl;
			}
			break;
		case '=':
			for (i = 0; i < r; i++)
			{
				for (j = 0; j < c; j++)
				{
					if (m1[i][j] != m2[i][j])
					{
						count++;
					}
				}
				cout << endl;
			}
			if (count > 0)
			{
				cout << "Not Equal Matrix" << endl;
			}
			else
			{
				cout << "Equal Matrix" << endl;
			}
			break;
		case 'D':
			cout << "Sum of diagonals of both martrix = " << endl;
			for (i = 0; i < r; i++)
			{
				for (j = 0; j < c; j++)
				{
					if (i == j)
					{
						product = m1[i][j] + m2[i][j];
						cout << product <<"  ";
					}
					else
					{
						cout << "  ";
					}
				}
				cout << endl;
			}
			break;
		default:
			cout << "Please Enter Correct Operation" << endl;
		}
		cout << "Enter Again a or A Choice if you wnat to use another operation = ";
		cin >> choice;
	} while (choice == 'a' || choice == 'A');
	system("pause");
}
