#include <iostream>
using namespace std;

int main()
{
    int height;
    char ch ;
    cout << "Enter height: ";
    cin >> height;
    for (int a = 1; a <= height;a++)
    {
        for (int b=height-a; b > 0; b--)
        {
            cout <<" ";
        }
        ch = 'a';
        for (int c = 1; c <= a ; c++)
        
        {
            cout << ch++;
        }
        cout <<"\n";
    }
    system("pause");
    return 0;
}

