#include<iostream>
#include<cstring>
using namespace std;
int main()
{
	string chr;
	cout<<"Write String:";
	getline(cin,chr);
	int x=chr.length();
	for( int i=0 ; i<x ; i++)
	{
		if(chr[i]>='A' && chr[i]<='Z')
		chr[i]+=32;
		else if(chr[i]>='a' && chr[i]<='z')
		chr[i]-=32;
		else if(chr[i])	
	}
	cout<<chr;
}
