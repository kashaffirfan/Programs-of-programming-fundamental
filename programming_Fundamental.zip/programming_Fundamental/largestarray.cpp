#include<iostream>
using namespace std;
int main()
{
	int size,lar1,lar2,array[size];
	cout<<"Enter size:";
	cin>>size;
	for(int i=0;i<size;i++)
	{
		cin>>array[i];
	}
	lar1=array[0];
	for(int i=0;i<size;i++)
	{
		if(lar1<=array[i])
		lar1=array[i];
	}
	lar2=array[0];
	for(int i=0;i<size;i++)
	{
		if(lar2<=array[i] && lar1!=array[i])
		lar2=array[i];
	}
	cout<<"Second Largest is:"<<lar2;
	return 0;
	
	
}

