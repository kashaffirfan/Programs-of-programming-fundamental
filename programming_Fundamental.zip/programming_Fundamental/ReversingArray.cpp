#include<iostream>
#include<cstring>
using namespace std;
int main()
{
	int array1[2][2], array2[2][2],a,b;
	cout<<"Enter numbers: "<<endl;
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			cin>>array1[i][j];
		}
	}
	cout<<"Original Array:"<<endl;
	for(int i=0;i<2;i++)
	{
		a=1;
		for(int j=0;j<2;j++)
		{
			cout<<array1[i][j]<<" ";
			array2[b][a]=array1[i][j];
			a--;
		}
		cout<<endl;
		b--;
	}
		cout<<"Array after reversing is:"<<endl;
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			cout<<array2[i][j]<<" ";
				
		}
		cout<<endl;
		
	}	
	return 0;
}

