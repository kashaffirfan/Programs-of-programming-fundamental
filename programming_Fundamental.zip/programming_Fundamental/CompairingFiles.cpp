#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	int a=0,b=0;
	char ch1,ch2;
	cout<<"Enter characters of first and to end enter '.'"<<endl;
	ofstream f1;
	f1.open("F1.txt");
	while(ch1!='.')
	{
		cin>>ch1;
		a++;
	    f1<<ch1;
	}
	f1.close();
	ofstream f2;
	f2.open("F2.txt");
	cout<<"\nEnter characters of second and to end enter '.'"<<endl;
	while(ch2!='.')
	{
		cin>>ch2;
		b++;
		f2<<ch2;
	}
	f2.close();
	if(a==b)
	{
		cout<<"Both files have same size.";
	}
	else if(a>b)
	{
		cout<<"File 1 is larger than file 2.";
	}
	else
	{
		cout<<"File 2 is larger than file 1.";
	}
	return 0;
}

