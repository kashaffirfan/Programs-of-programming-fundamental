#include <iostream>
using namespace std;
int main()
{
	int cash,drink=50,fries=100,snack=20;
	cout<<"Enter your cash=";
	cin>>cash;
	char choice;
	int quantity;
	
	do
	{
		if(cash>=drink || cash >=snack || cash >=fries)
	    {
	    cout<<"Enter D for drink , F for fries  ,S for snacks =";
	    cin>>choice;
	    cout<<endl;
	    if(choice=='D')
	    {
	    	cout<<"Entre no of Drinks: ";
	    	cin>>quantity;
	    	if(cash>=drink*quantity)
	        {
		        cout<<"Price of Drink is 50"<<endl;
		        cout<<"Total bill:"<< drink*quantity<<endl;
		        cash=cash-drink*quantity;
		        cout<<"remaining cash is ="<<cash;
	        }
	        else
	        cout<<"You haven't sufficient cash for drink";
		}
		if(choice=='F')		
	    {
	    	cout<<"Entre no of fries: ";
	    	cin>>quantity;
	    	if(cash>=fries*quantity)
	    	{
	    		cout<<"Price of Fries is 100"<<endl;
	    		cout<<"Total bill:"<< fries*quantity<<endl;
		        cash=cash-fries;
		        cout<<"remaining cash is ="<<cash<<endl;	
			}
			else
	        cout<<"You haven't sufficient cash for fries"; 
	    }
		if(choice=='S')
	    {
	    	cout<<"Entre no of Snacks: ";
	    	cin>>quantity;
	    	if(cash>=snack*quantity)
	    	{
	    		cout<<"Price of Snack is 20"<<endl;
	    		cout<<"Total bill:"<< snack*quantity<<endl;
		        cash=cash-snack;
		        cout<<"remaining cash is ="<<cash;
			}
			else
	        cout<<"You haven't sufficient cash for snack";
	    }
	    cout<<"\nEnter N if your order is completed & Y if you want to order more items=";
	    cin>>choice;
	}
	if(cash<20)
	break;
    } while(choice!='N');
    if(cash<20)
    cout<<"cash is not enough , Thanks for visiting";
    else
    cout<<"Your cash is ="<<cash<<endl<<"Thanks for visiting";
	return 0;	
}
