#include<iostream>
using namespace std;
int upper = 0, lower = 0, specialCharacters = 0, digit = 0;
char arr[4];
int function(char array[4])
{
	for (int i = 0; i < 4; i++)
	{
		if (array[i] >= 65 && array[i] <= 90)
		{
			upper++;
		}
		if (array[i] >= 97 && array[i] <= 122)
		{
			lower++;
		}
		if ((array[i] >= 33 && array[i] <= 47) || (array[i] >= 91 && array[i] <= 96))
		{
			specialCharacters++;
		}
		if(array[i]>=48 && array[i]<=57)
		{
			digit++;
		}

	}
}
int main()
{
	char arr[4];
	cout << "Enter password : ";
	for (int i = 0; i < 4; i++)
	{
		cin >> arr[i];
	}
	function(arr);
	if (digit == 1 && specialCharacters == 1 && lower== 1 && upper == 1)
		cout << "strong password";
	else
	{
		cout << "weak password";
	}

	return 0;
}

