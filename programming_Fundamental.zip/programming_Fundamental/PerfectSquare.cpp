#include <iostream> 
using namespace std; 
int main(){
    int num,i,sum=0;
    cout << "Enter a number: ";
    cin >> num;
    for(i=1;i<=num;i++)
	{
        if(num%i==0)
        cout<<"Divisor is "<<i<<endl;
        sum=sum+i;
        i++; 
        
    }
    if(sum==num)
    cout <<"Number is perfect square" ;
    else
    cout <<"Number is not a perfect square";
    system("pause"); 
return 0;
}
